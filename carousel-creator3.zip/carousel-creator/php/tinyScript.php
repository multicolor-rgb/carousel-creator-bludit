<script>

if(document.querySelector(".carousel-replace")){
  document.querySelector(".carousel-replace").outerHTML = `	<?php Theme::plugins('runCarousel');?>`
}
</script>